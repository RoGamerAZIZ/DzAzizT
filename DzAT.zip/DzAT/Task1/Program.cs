﻿// 1 Задача

Console.WriteLine("Напишите первое число: ");
int M = Convert.ToInt32(Console.ReadLine());
Console.WriteLine("Напишите второе число: ");
int N = Convert.ToInt32(Console.ReadLine());

string MtoN(int M, int N)
{
    if (M == N) return Convert.ToString(N);
    return M + " " + MtoN(M + 1, N);
}
Console.WriteLine(MtoN(M, N));

// 2 Задача

Console.Write("Напишите первое число: ");
int m = Convert.ToInt32(Console.ReadLine());
Console.Write("Напишите второе число: ");
int n = Convert.ToInt32(Console.ReadLine());

int akkerman(int m, int n)
{
    if (m == 0) return n + 1;
    else if (n == 0) return akkerman(m - 1, 1);
    else return akkerman(m - 1,akkerman(m,n - 1));
}
Console.Write(akkerman(m, n));

// 3 Задача

int[] mas = {1, 3, 6, 4, 2};
int i = mas.Length - 1;
int res = 0;
int masNum(int res)
{
    if (i >= 0)
    {
        res = masNum(res) + mas[i] + Convert.ToInt32(" ");
        i--;
        return masNum(res);
    }
    return masNum(res);
}
Console.WriteLine(masNum(res));
